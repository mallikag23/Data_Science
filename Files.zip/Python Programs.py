#!/usr/bin/env python
# coding: utf-8

# In[14]:


#Q11 to Q15 are programming questions. Answer them in Jupyter Notebook. 


# In[12]:


#11. Write a python program to find the factorial of a number.

import math
def factorial(n):
    return(math.factorial(n))
num = int(input('Enter Number :'))
print("Factorial of", num, ":",factorial(num))


# In[37]:


# 12. Write a python program to find whether a number is prime or composite.

try:
    number = int(input("Enter any number: "))
    if number > 1:
        for i in range(2, number):
            if (number % i) == 0 and number!=1 or 0 :
                print(number, "is a composite number")
                break
        else:
                print(number, "is a prime number")
    else:
        print(number, "is a not a Prime/ Composite Number")
except:
    print('Not a Interger')


# In[20]:


# 13. Write a python program to check whether a given string is palindrome or not. 

mystrg =input('Enter STRING :')
mystrg = mystrg.casefold()
revstrg = reversed(mystrg)
if list(mystrg) == list(revstrg):
    print("The string is a palindrome.")
else:
    print("The string is not a palindrome.")


# In[16]:


#14. Write a Python program to get the third side of right-angled triangle from two given sides. 

from math import sqrt

choice = input('Which side (a, b, c) of right-angled triangle want to calculate? side: ')
if choice == 'c':
        a = float(input('Enter the length of side a: '))
        b = float(input('Enter the length of side b: '))
        c = sqrt(a * a + b * b)
        print('length of side c is %g: ' %(c))
elif choice == 'b':
        a = float(input('Enter the length of side a: '))
        c = float(input('Enter the length of side c: '))
        b = sqrt(c * c - a * a)
        print('length of side b is %g: ' %(b))
elif choice == 'a':
        b = float(input('Enter the length of side b: '))
        c = float(input('Enter the length of side c: '))
        a = sqrt((c * c) - (b * b))
        print('length of side a is %g: ' %(a))
else:
    print('Invalid Input!')


# In[39]:


#15. Write a python program to print the frequency of each of the characters present in a given string.
from collections import Counter

intstg = input('Enter STRING :')
feqchar = Counter(intstg)
print ("Frequency of characters in '{}' is :\n {}".format(intstg, str(feqchar)))


# In[ ]:




